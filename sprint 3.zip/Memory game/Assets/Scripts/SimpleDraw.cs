using UnityEngine;

public class SimpleDraw : MonoBehaviour
{
    public GameObject linePrefab;
    private LineRenderer lineRenderer;

    void Start()
    {
        var line = Instantiate(linePrefab);
        lineRenderer = line.GetComponent<LineRenderer>();
        lineRenderer.positionCount = 2;
        lineRenderer.SetPosition(0, Camera.main.ScreenToWorldPoint(new Vector3(0, 0, 10)));
        lineRenderer.SetPosition(1, Camera.main.ScreenToWorldPoint(new Vector3(Screen.width, Screen.height, 10)));
    }
}
