using UnityEngine;
using UnityEngine.SceneManagement;

public class BackButton : MonoBehaviour
{
    public void GoToSelectGameMode()
    {
        SceneManager.LoadScene("SelectGameMode");
    }
}
