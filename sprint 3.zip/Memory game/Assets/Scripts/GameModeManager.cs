using UnityEngine;
using UnityEngine.SceneManagement;

public class GameModeManager : MonoBehaviour
{
public void LoadCardGame()
{
    SceneManager.LoadScene("CardGame");
}

public void LoadSwipeGame()
{
    SceneManager.LoadScene("SwipeGame");
}

public void LoadDrawing()
{
    SceneManager.LoadScene("Drawing");
}
}
