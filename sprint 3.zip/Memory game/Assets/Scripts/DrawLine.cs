using System.Collections.Generic;
using UnityEngine;

public class DrawLine : MonoBehaviour
{
    public GameObject linePrefab;            
    private GameObject currentLine;          
    private LineRenderer lineRenderer;      
    private EdgeCollider2D edgeCollider;     
    private List<Vector2> fingerPositions;   

    void Start()
    {
        fingerPositions = new List<Vector2>();
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            CreateLine();  
        }
        else if (Input.GetMouseButton(0) && currentLine != null)
        {
            Vector2 newPoint = GetMouseWorldPosition();
            if (Vector2.Distance(newPoint, fingerPositions[fingerPositions.Count - 1]) > 0.1f)
            {
                UpdateLine(newPoint);  
            }
        }
    }

    void CreateLine()
    {
        currentLine = Instantiate(linePrefab, Vector3.zero, Quaternion.identity);
        lineRenderer = currentLine.GetComponent<LineRenderer>();
        edgeCollider = currentLine.GetComponent<EdgeCollider2D>();

        fingerPositions.Clear();
        Vector2 startPoint = GetMouseWorldPosition();
        fingerPositions.Add(startPoint);
        fingerPositions.Add(startPoint);

        lineRenderer.positionCount = 2;
        lineRenderer.SetPosition(0, startPoint);
        lineRenderer.SetPosition(1, startPoint);

        edgeCollider.points = fingerPositions.ToArray();
    }

    void UpdateLine(Vector2 newPoint)
    {
        fingerPositions.Add(newPoint);
        lineRenderer.positionCount = fingerPositions.Count;
        lineRenderer.SetPosition(lineRenderer.positionCount - 1, newPoint);
        edgeCollider.points = fingerPositions.ToArray();
    }

    Vector2 GetMouseWorldPosition()
    {
        Vector3 mousePos = Input.mousePosition;
        mousePos.z = 10;  
        return Camera.main.ScreenToWorldPoint(mousePos);
    }
}
