using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;  
using TMPro;         

public class LineConnect : MonoBehaviour
{
    public GameObject linePrefab;               
    private GameObject currentLine;             
    private LineRenderer lineRenderer;           
    private List<Vector2> fingerPositions;       
    private GameObject startObject = null;      
    private bool isDragging = false;           

    [Header("Connection Rules")]
    public List<GameObject> flags;              
    public List<GameObject> words;             
    public Dictionary<GameObject, GameObject> validConnections; 

    [Header("UI")]
    public GameObject popUpPanel;               
    public TextMeshProUGUI popUpText;                     

    private int correctConnections = 0;         
    private int totalConnections = 3;          
    private List<GameObject> connectedFlags = new List<GameObject>(); 
    private List<GameObject> connectedWords = new List<GameObject>(); 
    private List<GameObject> drawnLines = new List<GameObject>(); 

    void Start()
    {
        fingerPositions = new List<Vector2>();

        
        validConnections = new Dictionary<GameObject, GameObject>
        {
            { flags[0], words[0] },  
            { flags[1], words[1] },  
            { flags[2], words[2] }   
        };

       
        popUpPanel.SetActive(false);
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            
            GameObject clickedObject = GetClickedObject();

            if (clickedObject != null && flags.Contains(clickedObject))
            {
              
                startObject = clickedObject;
                CreateLine();
                isDragging = true;
            }
        }
        else if (Input.GetMouseButton(0) && isDragging && currentLine != null)
        {
            Vector2 currentMousePosition = GetMouseWorldPosition();
            UpdateLine(currentMousePosition);
        }
        else if (Input.GetMouseButtonUp(0) && isDragging)
        {
            GameObject releasedObject = GetClickedObject();

            if (releasedObject != null && words.Contains(releasedObject))
            {
                if (validConnections.TryGetValue(startObject, out GameObject correctWord) && correctWord == releasedObject)
                {
                    Vector2 endPoint = GetMouseWorldPosition();
                    UpdateLine(endPoint);
                    Debug.Log($"Valid connection: {startObject.name} -> {releasedObject.name}");
                    correctConnections++; 

                    connectedFlags.Add(startObject);
                    connectedWords.Add(releasedObject);
                }
                else
                {
                    Debug.LogError($"Invalid connection: {startObject.name} -> {releasedObject?.name ?? "Nothing"}");
                    ResetLine();
                }
            }
            else
            {
                Debug.LogError("Drag released, but no valid target found.");
                ResetLine(); 
            }

           
            isDragging = false; 
            CheckForCompletion(); 
        }
    }

    void CreateLine()
    {
        currentLine = Instantiate(linePrefab, Vector3.zero, Quaternion.identity);
        lineRenderer = currentLine.GetComponent<LineRenderer>();
        fingerPositions.Clear();

        Vector2 startPoint = GetMouseWorldPosition();
        fingerPositions.Add(startPoint);
        fingerPositions.Add(startPoint);

        lineRenderer.positionCount = 2;
        lineRenderer.SetPosition(0, startPoint);
        lineRenderer.SetPosition(1, startPoint);

        drawnLines.Add(currentLine);
    }

    void UpdateLine(Vector2 newPoint)
    {
        if (fingerPositions.Count == 2)
        {
            fingerPositions[1] = newPoint; 
        }
        else
        {
            fingerPositions.Add(newPoint);
        }

        lineRenderer.positionCount = fingerPositions.Count;
        lineRenderer.SetPosition(lineRenderer.positionCount - 1, newPoint);
    }

    void ResetLine()
    {
        if (currentLine != null)
        {
            Destroy(currentLine); 
            currentLine = null;   
        }

        startObject = null;       
        fingerPositions.Clear(); 
    }

    Vector2 GetMouseWorldPosition()
    {
        Vector3 mousePos = Input.mousePosition;
        mousePos.z = 10; 
        return Camera.main.ScreenToWorldPoint(mousePos);
    }

    GameObject GetClickedObject()
    {
        Vector2 mousePosition = GetMouseWorldPosition();
        RaycastHit2D hit = Physics2D.Raycast(mousePosition, Vector2.zero);

        if (hit.collider != null)
        {
            return hit.collider.gameObject;
        }

        return null;
    }

    void CheckForCompletion()
    {
        
        if (correctConnections == totalConnections)
        {
            ShowPopUpMessage("Good Job! All flags connected!");
            DeactivateConnectedObjects(); 
            DeactivateLines();            
        }
    }

    void ShowPopUpMessage(string message)
    {
        popUpPanel.SetActive(true);  
        popUpText.text = message;   
    }

    void DeactivateConnectedObjects()
    {
        
        foreach (var flag in connectedFlags)
        {
            flag.SetActive(false);  
        }

        foreach (var word in connectedWords)
        {
            word.SetActive(false);  
        }
    }

    void DeactivateLines()
    {
        foreach (var line in drawnLines)
        {
            line.SetActive(false);  
        }
    }
}
