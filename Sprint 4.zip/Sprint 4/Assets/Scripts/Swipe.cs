using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SwipeMemoryGame : MonoBehaviour
{
    public Image PageImage;                    
    public Image WhiteScreenOverlay;            
    public List<Sprite> Numbers;                 
    public TextMeshProUGUI ScoreText;                      
    public float displayInterval = 1f;           
    public float swipeThreshold = 50f;           
    public float transitionDuration = 1f;        
    public float pauseAfterGuessDuration = 1f;   
    public float rotationFrequency = 0.2f;      

    private List<int> sequence = new List<int>();  
    private int currentLevel = 1;                 
    private bool isShowingSequence = false;      
    private int randomIndex;                      

    private Vector2 startTouchPosition;
    private Vector2 endTouchPosition;

    private int score = 0;                       

    private void Start()
    {
        WhiteScreenOverlay.gameObject.SetActive(false); 
        UpdateScoreText();
        StartNewLevel();
    }

    private void Update()
    {
        if (isShowingSequence) return;  

        #if UNITY_EDITOR
        
        if (Input.GetMouseButtonDown(0))
        {
            startTouchPosition = Input.mousePosition;
        }

        if (Input.GetMouseButtonUp(0))
        {
            endTouchPosition = Input.mousePosition;
            DetectSwipe();
        }
        #else
        
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            if (touch.phase == TouchPhase.Began)
            {
                startTouchPosition = touch.position;
            }

            if (touch.phase == TouchPhase.Ended)
            {
                endTouchPosition = touch.position;
                DetectSwipe();
            }
        }
        #endif
    }

    private void StartNewLevel()
    {
        sequence.Clear();
        for (int i = 0; i < currentLevel; i++)
        {
            sequence.Add(Random.Range(0, Numbers.Count));  
        }

        StartCoroutine(ShowSequence());  
    }

    private IEnumerator ShowSequence()
    {
        isShowingSequence = true;

       
        foreach (int index in sequence)
        {
            PageImage.sprite = Numbers[index];
            yield return new WaitForSeconds(displayInterval);
        }

        WhiteScreenOverlay.gameObject.SetActive(true);
        yield return new WaitForSeconds(transitionDuration);  
        WhiteScreenOverlay.gameObject.SetActive(false);

        ShowRandomSprite();
        isShowingSequence = false;
    }

    private void ShowRandomSprite()
    {
        randomIndex = Random.Range(0, Numbers.Count);
        PageImage.sprite = Numbers[randomIndex];

        if (Random.value < rotationFrequency)
        {
            float[] rotationAngles = { 0f, 90f, 180f, 270f };
            float randomRotation = rotationAngles[Random.Range(0, rotationAngles.Length)];

            PageImage.transform.rotation = Quaternion.Euler(0f, 0f, randomRotation);
        }
        else
        {
            PageImage.transform.rotation = Quaternion.identity;
        }
    }

    private void DetectSwipe()
    {
        float swipeDistance = endTouchPosition.x - startTouchPosition.x;

        if (Mathf.Abs(swipeDistance) > swipeThreshold)
        {
            if (swipeDistance > 0)
            {
                PlayerAnswer(true); 
            }
            else
            {
                PlayerAnswer(false); 
            }
        }
    }

    private void PlayerAnswer(bool playerSaidYes)
    {
        bool isCorrectAnswer = sequence.Contains(randomIndex);

        if (playerSaidYes == isCorrectAnswer)
        {
            Debug.Log("Correct! Moving to the next level.");
            score++; 
            UpdateScoreText();  
        }
        else
        {
            Debug.Log("Incorrect. Try again!");
        }

        StartCoroutine(PauseBeforeNextLevel());
    }

    private IEnumerator PauseBeforeNextLevel()
    {
        yield return new WaitForSeconds(pauseAfterGuessDuration);

        if (sequence.Contains(randomIndex)) 
        {
            currentLevel++;  
        }

        PageImage.transform.rotation = Quaternion.identity;
        StartNewLevel(); 
    }

    private void UpdateScoreText()
    {
        ScoreText.text = "Score: " + score;
    }
}
