using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro; 

public class BackButton : MonoBehaviour
{
    public TextMeshProUGUI backText; 

    void Start()
    {
    }

    public void GoToSelectGameMode()
    {
        SceneManager.LoadScene("SelectGameMode");
    }
}
