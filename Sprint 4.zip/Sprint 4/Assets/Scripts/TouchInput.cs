using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class TouchInputHandler : MonoBehaviour
{
    private Camera mainCamera;
    private GameManager gameManager;

    private void Awake()
    {
        mainCamera = Camera.main;
        gameManager = FindObjectOfType<GameManager>();  
    }

    private void Update()
    {
        
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            if (touch.phase == TouchPhase.Began)
            {
                Vector2 touchPosition = touch.position;
                Ray ray = mainCamera.ScreenPointToRay(touchPosition);
                RaycastHit hit;

                if (Physics.Raycast(ray, out hit))
                {
                    Button selectedButton = hit.collider.GetComponent<Button>();
                    if (selectedButton != null)
                    {
                    
                        gameManager.PickPuzzle(selectedButton);
                    }
                }
            }
        }
    }
}