using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DrawLine : MonoBehaviour
{
    public GameObject linePrefab;          
    public SimpleDraw simpleDraw;          
    public float maxDistance = 0.5f;       
    public TextMeshProUGUI accuracyText;              

    private GameObject currentLine;        
    private LineRenderer lineRenderer;      
    private EdgeCollider2D edgeCollider;    
    private List<Vector2> fingerPositions;  

    void Start()
    {
        fingerPositions = new List<Vector2>();
    }

    void Update()
    {
        
        if (Input.GetMouseButtonDown(0))
        {
            CreateLine();
        }
        
        else if (Input.GetMouseButton(0) && currentLine != null)
        {
            Vector2 newPoint = GetMouseWorldPosition();
            if (Vector2.Distance(newPoint, fingerPositions[fingerPositions.Count - 1]) > 0.1f)
            {
                UpdateLine(newPoint);
            }
        }
        
        else if (Input.GetMouseButtonUp(0))
        {
            float accuracy = CalculateAccuracy();
            Debug.Log($"De gebruiker heeft de lijn getekend met {accuracy}% precisie.");
        }
    }

    void CreateLine()
    {
        currentLine = Instantiate(linePrefab, Vector3.zero, Quaternion.identity);
        lineRenderer = currentLine.GetComponent<LineRenderer>();
        edgeCollider = currentLine.GetComponent<EdgeCollider2D>();

        fingerPositions.Clear();
        Vector2 startPoint = GetMouseWorldPosition();
        fingerPositions.Add(startPoint);
        fingerPositions.Add(startPoint);

        lineRenderer.positionCount = 2;
        lineRenderer.SetPosition(0, startPoint);
        lineRenderer.SetPosition(1, startPoint);

        edgeCollider.points = fingerPositions.ToArray();
    }

    void UpdateLine(Vector2 newPoint)
    {
        fingerPositions.Add(newPoint);
        lineRenderer.positionCount = fingerPositions.Count;
        lineRenderer.SetPosition(lineRenderer.positionCount - 1, newPoint);
        edgeCollider.points = fingerPositions.ToArray();
    }

    Vector2 GetMouseWorldPosition()
    {
        Vector3 mousePos = Input.mousePosition;
        mousePos.z = 10;  
        return Camera.main.ScreenToWorldPoint(mousePos);
    }

    public float CalculateAccuracy()
    {
        int validPoints = 0;

        foreach (Vector2 fingerPoint in fingerPositions)
        {
            if (IsCloseToExampleLine(fingerPoint))
            {
                validPoints++;
            }
        }

       
        float accuracy = (float)validPoints / fingerPositions.Count * 100f;

       
        if (accuracyText != null)
        {
            accuracyText.text = $"Precisie: {accuracy:F1}%";
        }

        return accuracy;
    }

    bool IsCloseToExampleLine(Vector2 point)
    {
        for (int i = 0; i < simpleDraw.exampleLinePoints.Count - 1; i++)
        {
            Vector2 start = simpleDraw.exampleLinePoints[i];
            Vector2 end = simpleDraw.exampleLinePoints[i + 1];
            float distance = DistanceToLineSegment(point, start, end);

            if (distance <= maxDistance)
            {
                return true;
            }
        }
        return false;
    }

    float DistanceToLineSegment(Vector2 point, Vector2 start, Vector2 end)
    {
        float lengthSquared = (end - start).sqrMagnitude;
        if (lengthSquared == 0f)
        {
            return Vector2.Distance(point, start);
        }

        float t = Mathf.Clamp01(Vector2.Dot(point - start, end - start) / lengthSquared);
        Vector2 projection = start + t * (end - start);
        return Vector2.Distance(point, projection);
    }
}
