using UnityEngine;
using Unity.Barracuda;
using UnityEngine.UI;
using TMPro;

public class HandwritingRecognition : MonoBehaviour
{
    public NNModel modelAsset;  // The MNIST ONNX model
    private IWorker worker;  // The worker for model inference

    public LineRenderer lineRenderer;  // To capture the drawing
    private Texture2D drawingTexture;  // The texture we will use to convert the drawing into an image

    public TextMeshProUGUI resultText;  // Reference to the UI Text element to show the result

    void Start()
    {
        // Load the model using Barracuda
        var model = ModelLoader.Load(modelAsset);
        worker = WorkerFactory.CreateWorker(WorkerFactory.Type.ComputePrecompiled, model);

        // Create a blank texture for the drawing
        drawingTexture = new Texture2D(28, 28);
    }

    void Update()
    {
        // Capture drawing input
        if (Input.GetMouseButton(0))
        {
            Vector2 mousePos = GetMouseWorldPosition();
            Vector2[] positions = new Vector2[] { mousePos };

            // Use LineRenderer to draw points
            lineRenderer.positionCount++;
            lineRenderer.SetPosition(lineRenderer.positionCount - 1, mousePos);

            // Debug: Print out mouse world position
            Debug.Log("Mouse World Position: " + mousePos);
        }

        // When user finishes drawing (on mouse release), recognize the number
        if (Input.GetMouseButtonUp(0))
        {
            RecognizeDrawing();
        }
    }

    void RecognizeDrawing()
    {
        // Convert the drawn points into a 28x28 image
        ConvertDrawingToTexture();

        // Feed the image into the neural network
        Tensor inputTensor = new Tensor(drawingTexture, channels: 1);  // 1 channel for grayscale

        // Run the model with the input tensor and get the output tensor
        Tensor outputTensor = worker.Execute(inputTensor).PeekOutput(); // Correct way to get output tensor

        // Get the predicted digit (the class with the highest probability)
        float[] output = outputTensor.ToReadOnlyArray();
        int predictedDigit = ArgMax(output);

        // Display the predicted digit in the Debug console
        Debug.Log("Predicted Digit: " + predictedDigit);

        // Update the UI Text element with the predicted number
        resultText.text = "Predicted Digit: " + predictedDigit;
    }

    void ConvertDrawingToTexture()
    {
        // Create a blank 28x28 texture (pixels array) to store the drawing
        Color[] pixels = new Color[28 * 28];

        // Clear the texture to white (background)
        for (int i = 0; i < pixels.Length; i++)
        {
            pixels[i] = Color.white;  // Set all pixels to white initially
        }

        // Capture the drawn points from the LineRenderer
        Vector3[] positions = new Vector3[lineRenderer.positionCount];
        lineRenderer.GetPositions(positions);

        // Debugging: Print out the line renderer positions
        Debug.Log("Captured Drawing Points: ");
        foreach (var pos in positions)
        {
            Debug.Log("Position: " + pos);
        }

        // Get the bounds of the drawing (to normalize it properly)
        float minX = Mathf.Infinity, maxX = -Mathf.Infinity;
        float minY = Mathf.Infinity, maxY = -Mathf.Infinity;

        // Calculate the min and max bounds of the drawing
        foreach (var pos in positions)
        {
            minX = Mathf.Min(minX, pos.x);
            maxX = Mathf.Max(maxX, pos.x);
            minY = Mathf.Min(minY, pos.y);
            maxY = Mathf.Max(maxY, pos.y);
        }

        // Debugging: Log the min and max bounds of the drawing
        Debug.Log($"Drawing bounds: minX = {minX}, maxX = {maxX}, minY = {minY}, maxY = {maxY}");

        // Normalize the drawing and map to the 28x28 grid
        // Calculate the scaling factors
        float scaleX = 27f / Mathf.Max(maxX - minX, 0.01f); // Avoid division by zero
        float scaleY = 27f / Mathf.Max(maxY - minY, 0.01f); // Avoid division by zero
        float offsetX = (27f - (maxX + minX) * scaleX) / 2f; // Center the drawing
        float offsetY = (27f - (maxY + minY) * scaleY) / 2f; // Center the drawing

        // Map positions to 28x28 grid
        for (int i = 0; i < positions.Length; i++)
        {
            // Normalize and scale the coordinates to fit into the 28x28 grid
            float normalizedX = (positions[i].x - minX) * scaleX + offsetX;
            float normalizedY = (positions[i].y - minY) * scaleY + offsetY;

            // Debugging: Log the normalized coordinates
            Debug.Log($"Normalized coordinates: x = {normalizedX}, y = {normalizedY}");

            // Convert to pixel indices (ensure it's within bounds)
            int pixelX = Mathf.Clamp(Mathf.FloorToInt(normalizedX), 0, 27);
            int pixelY = Mathf.Clamp(Mathf.FloorToInt(normalizedY), 0, 27);

            // Debugging: Log the pixel coordinates
            Debug.Log($"Mapped to pixel: x = {pixelX}, y = {pixelY}");

            // Set the corresponding pixel to black (the drawing color)
            pixels[pixelY * 28 + pixelX] = Color.black;
        }

        // Apply the pixels to the texture
        drawingTexture.SetPixels(pixels);
        drawingTexture.Apply();

        // Debugging: Output the texture pixel data row by row
        Debug.Log("Texture Pixel Data: ");
        for (int i = 0; i < 28; i++)  // Print the texture row by row
        {
            string row = "";
            for (int j = 0; j < 28; j++)
            {
                row += pixels[i * 28 + j] == Color.black ? "1 " : "0 ";
            }
            Debug.Log(row);  // Print each row of the texture
        }
    }

    int ArgMax(float[] array)
    {
        // Find the index with the highest probability
        int maxIndex = 0;
        for (int i = 1; i < array.Length; i++)
        {
            if (array[i] > array[maxIndex])
                maxIndex = i;
        }
        return maxIndex;
    }

    // Convert the screen mouse position to world space
    Vector2 GetMouseWorldPosition()
    {
        Vector3 mousePos = Input.mousePosition;
        mousePos.z = 10;  // Set a distance for the camera
        return Camera.main.ScreenToWorldPoint(mousePos);
    }

    void OnApplicationQuit()
    {
        // Dispose the worker when the application quits
        worker.Dispose();
    }
}
