using UnityEngine;
using System.Collections.Generic;

public class SimpleDraw : MonoBehaviour
{
    public GameObject linePrefab; 
    public int numberOfPoints = 10; 
    public float lineWidth = 0.2f;
    public float xRange = 10f; 
    public float yRange = 5f; 

    [HideInInspector] public List<Vector2> exampleLinePoints;    private LineRenderer lineRenderer;

    void Start()
    {
        exampleLinePoints = new List<Vector2>();
        GenerateRandomLine();
    }

    void GenerateRandomLine()
    {
        
        var line = Instantiate(linePrefab);
        lineRenderer = line.GetComponent<LineRenderer>();
        lineRenderer.startWidth = lineWidth;
        lineRenderer.endWidth = lineWidth;

        
        Vector2 startPoint = new Vector2(-xRange / 2, 0);
        exampleLinePoints.Add(startPoint);

        for (int i = 1; i < numberOfPoints; i++)
        {
            float x = exampleLinePoints[i - 1].x + Random.Range(1f, xRange / numberOfPoints);
            float y = Random.Range(-yRange, yRange);
            exampleLinePoints.Add(new Vector2(x, y));
        }

       
        lineRenderer.positionCount = exampleLinePoints.Count;
        for (int i = 0; i < exampleLinePoints.Count; i++)
        {
            lineRenderer.SetPosition(i, exampleLinePoints[i]);
        }
    }
}
